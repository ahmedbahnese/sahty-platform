-- Egypt Healthcare Facilities Database
-- Date: 2026-08-06

INSERT INTO governorates (id, name_ar, name_en) VALUES (1, 'القاهرة', 'Cairo');
INSERT INTO governorates (id, name_ar, name_en) VALUES (2, 'الإسكندرية', 'Alexandria');
INSERT INTO governorates (id, name_ar, name_en) VALUES (3, 'البحيرة', 'Beheira');
INSERT INTO facility_types (id, name_ar, name_en) VALUES (1, 'مستشفى تعليمي', 'Teaching Hospital');
INSERT INTO facility_types (id, name_ar, name_en) VALUES (2, 'مستشفى جامعي', 'University Hospital');
INSERT INTO facility_types (id, name_ar, name_en) VALUES (3, 'مستشفى خاص', 'Private Hospital');
INSERT INTO facility_types (id, name_ar, name_en) VALUES (4, 'مستشفى عام', 'General Hospital');
INSERT INTO facility_types (id, name_ar, name_en) VALUES (5, 'معمل تحاليل', 'Laboratory');
INSERT INTO facility_types (id, name_ar, name_en) VALUES (6, 'صيدلية', 'Pharmacy');
INSERT INTO ownership_types (id, name_ar, name_en) VALUES (1, 'حكومي', 'Government');
INSERT INTO ownership_types (id, name_ar, name_en) VALUES (2, 'خاص', 'Private');
INSERT INTO ownership_types (id, name_ar, name_en) VALUES (3, 'جامعي', 'University');
INSERT INTO facilities (name_ar, name_en, full_address, google_maps_url, latitude, longitude, phone_numbers, is_24_hours, has_emergency_dept, has_icu, data_source) VALUES ('مستشفى أحمد ماهر التعليمي', 'Ahmed Maher Teaching Hospital', '341 Port Said St, El Sayeda Zeinab, Cairo', 'https://goo.gl/maps/AhmedMaher', 30.0444, 31.2357, '02-23911670', TRUE, TRUE, TRUE, 'MOHP Official');
INSERT INTO facilities (name_ar, name_en, full_address, google_maps_url, latitude, longitude, phone_numbers, is_24_hours, has_emergency_dept, has_icu, data_source) VALUES ('مستشفى الجلاء التعليمي للولادة', 'El Galaa Maternity Teaching Hospital', '41 26th of July St, Downtown, Cairo', 'https://goo.gl/maps/ElGalaa', 30.0545, 31.2376, '02-25756474', TRUE, TRUE, TRUE, 'MOHP Official');
INSERT INTO facilities (name_ar, name_en, full_address, google_maps_url, latitude, longitude, phone_numbers, is_24_hours, has_emergency_dept, has_icu, data_source) VALUES ('مستشفى الساحل التعليمي', 'Al Sahel Teaching Hospital', '2 Youssef Karam, El Sahel, Cairo', 'https://goo.gl/maps/AlSahel', 30.0833, 31.25, '01020186351', TRUE, TRUE, TRUE, 'MOHP Official');
INSERT INTO facilities (name_ar, name_en, full_address, google_maps_url, latitude, longitude, phone_numbers, is_24_hours, has_emergency_dept, has_icu, data_source) VALUES ('مستشفى قصر العيني', 'Kasr Al-Ainy Hospital', 'Al-Saray Street, El Manial, Cairo', 'https://goo.gl/maps/KasrAlAiny', 30.0303, 31.2294, '02-23647545', TRUE, TRUE, TRUE, 'Cairo University');
INSERT INTO facilities (name_ar, name_en, full_address, google_maps_url, latitude, longitude, phone_numbers, is_24_hours, has_emergency_dept, has_icu, data_source) VALUES ('مستشفى كليوباترا', 'Cleopatra Hospital', '39 Cleopatra St, Heliopolis, Cairo', 'https://goo.gl/maps/Cleopatra', 30.0911, 31.3289, '02-24143931', TRUE, TRUE, TRUE, 'Cleopatra Group');
INSERT INTO facilities (name_ar, name_en, full_address, google_maps_url, latitude, longitude, phone_numbers, is_24_hours, has_emergency_dept, has_icu, data_source) VALUES ('مستشفى الجمهورية العام', 'Al Gomhouria General Hospital', 'Mahmoudia Canal Street, Alexandria', 'https://goo.gl/maps/AlGomhouria', 31.185, 29.895, '03-3608027', TRUE, TRUE, TRUE, 'Alexandria Health Directorate');
INSERT INTO facilities (name_ar, name_en, full_address, google_maps_url, latitude, longitude, phone_numbers, is_24_hours, has_emergency_dept, has_icu, data_source) VALUES ('مستشفى الشاطبي الجامعي للأطفال', 'Shatby University Hospital for Children', 'El-Gaish Rd, Al Azaritah, Alexandria', 'https://goo.gl/maps/Shatby', 31.21, 29.91, '03-4873500', TRUE, TRUE, TRUE, 'Alexandria University');
INSERT INTO facilities (name_ar, name_en, full_address, google_maps_url, latitude, longitude, phone_numbers, is_24_hours, has_emergency_dept, has_icu, data_source) VALUES ('مستشفى دمنهور التعليمي', 'Damanhour Teaching Hospital', 'Gomhoria Street, Damanhour, Beheira', 'https://goo.gl/maps/Damanhour', 31.0333, 30.4667, '045-3318222', TRUE, TRUE, TRUE, 'MOHP Official');
INSERT INTO facilities (name_ar, name_en, full_address, google_maps_url, latitude, longitude, phone_numbers, is_24_hours, has_emergency_dept, has_icu, data_source) VALUES ('معامل البرج - فرع القاهرة', 'Al Borg Laboratories - Cairo', 'Mohandessin, Cairo', 'https://goo.gl/maps/AlBorgCairo', 30.05, 31.2, '19911', FALSE, FALSE, FALSE, 'Al Borg Labs');
INSERT INTO facilities (name_ar, name_en, full_address, google_maps_url, latitude, longitude, phone_numbers, is_24_hours, has_emergency_dept, has_icu, data_source) VALUES ('صيدلية العزبي - فرع القاهرة', 'El Ezaby Pharmacy - Cairo', 'New Cairo, Cairo', 'https://goo.gl/maps/ElEzabyCairo', 30.0, 31.4, '19600', TRUE, FALSE, FALSE, 'El Ezaby');
